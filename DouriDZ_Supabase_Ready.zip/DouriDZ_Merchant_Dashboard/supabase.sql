create extension if not exists pgcrypto;

create table if not exists businesses (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category text,
  city text,
  is_open boolean default true,
  created_at timestamptz default now()
);

create table if not exists tickets (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references businesses(id) on delete cascade,
  device_id text not null,
  ticket_number integer not null,
  status text not null default 'waiting' check (status in ('waiting','serving','done','cancelled')),
  created_at timestamptz default now(),
  called_at timestamptz
);

create index if not exists tickets_business_status_idx on tickets(business_id,status,ticket_number);

alter table businesses enable row level security;
alter table tickets enable row level security;

drop policy if exists businesses_public_read on businesses;
create policy businesses_public_read on businesses for select to anon, authenticated using (true);

drop policy if exists tickets_public_read on tickets;
create policy tickets_public_read on tickets for select to anon, authenticated using (true);

create or replace function take_ticket(p_business_id uuid, p_device_id text)
returns json language plpgsql security definer as $$
declare next_no int; ahead int;
begin
  select coalesce(max(ticket_number),0)+1 into next_no from tickets where business_id=p_business_id;
  insert into tickets(business_id,device_id,ticket_number,status) values(p_business_id,p_device_id,next_no,'waiting');
  select count(*) into ahead from tickets where business_id=p_business_id and status='waiting' and ticket_number < next_no;
  return json_build_object('ticket_number',next_no,'people_ahead',ahead);
end; $$;

grant execute on function take_ticket(uuid,text) to anon, authenticated;

create or replace function call_next(p_business_id uuid)
returns json language plpgsql security definer as $$
declare current_id uuid; next_no int;
begin
  update tickets set status='done' where business_id=p_business_id and status='serving';
  select id,ticket_number into current_id,next_no from tickets where business_id=p_business_id and status='waiting' order by ticket_number limit 1;
  if current_id is null then return json_build_object('ok',false); end if;
  update tickets set status='serving',called_at=now() where id=current_id;
  return json_build_object('ok',true,'ticket_number',next_no);
end; $$;

grant execute on function call_next(uuid) to anon, authenticated;

insert into businesses(id,name,category,city,is_open)
values('00000000-0000-0000-0000-000000000001','مطعم مذاق الجزائر','مطعم','الجزائر',true)
on conflict (id) do nothing;

alter table tickets replica identity full;

-- Douri DZ v1.1: cancel ticket safely by device
create or replace function cancel_ticket(p_business_id uuid, p_device_id text, p_ticket_number int)
returns json language plpgsql security definer as $$
begin
  update tickets set status='cancelled'
  where business_id=p_business_id and device_id=p_device_id and ticket_number=p_ticket_number and status in ('waiting','serving');
  return json_build_object('ok',true);
end; $$;
grant execute on function cancel_ticket(uuid,text,int) to anon, authenticated;

insert into businesses(id,name,category,city,is_open) values
('00000000-0000-0000-0000-000000000002','Fast Food الجيل','مطعم','الجزائر',true),
('00000000-0000-0000-0000-000000000003','صالون الحلقة الأنيق','حلاق','الجزائر',true),
('00000000-0000-0000-0000-000000000004','عيادة الحياة','عيادة','الجزائر',false)
on conflict (id) do nothing;

-- Douri DZ v1.2: private identity verification storage
create table if not exists business_verifications (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references businesses(id) on delete cascade,
  device_id text not null,
  id_card_path text not null,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at timestamptz default now(),
  reviewed_at timestamptz
);
create index if not exists business_verifications_business_idx on business_verifications(business_id,status);
alter table business_verifications enable row level security;
drop policy if exists verification_insert_anon on business_verifications;
create policy verification_insert_anon on business_verifications for insert to authenticated with check (status='pending');
drop policy if exists verification_no_public_read on business_verifications;
-- No public SELECT policy: verification records are private and should be reviewed from a protected admin environment.

insert into storage.buckets (id, name, public)
values ('id-verification','id-verification',false)
on conflict (id) do update set public=false;

drop policy if exists id_verification_upload on storage.objects;
create policy id_verification_upload on storage.objects for insert to authenticated
with check (bucket_id='id-verification' and (storage.foldername(name))[1] is not null);
-- Deliberately no public SELECT/UPDATE/DELETE policy for identity images.


-- Douri DZ v1.3: phone authentication / owner profile
create table if not exists user_profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  phone text,
  role text not null default 'customer' check (role in ('customer','merchant')),
  created_at timestamptz default now()
);
alter table user_profiles enable row level security;
drop policy if exists profile_self on user_profiles;
create policy profile_self on user_profiles for all to authenticated using (auth.uid()=user_id) with check (auth.uid()=user_id);

alter table businesses add column if not exists latitude double precision;
alter table businesses add column if not exists longitude double precision;
alter table businesses add column if not exists address text;
create index if not exists businesses_location_idx on businesses(latitude,longitude);

alter table businesses add column if not exists owner_user_id uuid references auth.users(id);
create index if not exists businesses_owner_idx on businesses(owner_user_id);

-- Recommended production hardening: enable the Phone provider in Supabase Auth settings and configure an SMS provider.
-- The app uses signInWithOtp/verifyOtp and does not treat phone verification as business verification.


-- Douri DZ v1.4: server-side verification gate for merchant dashboard
create or replace function get_my_verification_status()
returns json language plpgsql security definer as $$
declare st text; bid uuid;
begin
  select b.id into bid from businesses b where b.owner_user_id=auth.uid() order by b.created_at desc limit 1;
  if bid is null then return json_build_object('status','none'); end if;
  select v.status into st from business_verifications v where v.business_id=bid order by v.created_at desc limit 1;
  return json_build_object('status',coalesce(st,'none'),'business_id',bid);
end; $$;
grant execute on function get_my_verification_status() to authenticated;

create or replace function merchant_dashboard_access()
returns json language plpgsql security definer as $$
declare st text; bid uuid;
begin
  select b.id into bid from businesses b where b.owner_user_id=auth.uid() order by b.created_at desc limit 1;
  if bid is null then return json_build_object('allowed',false,'status','none'); end if;
  select v.status into st from business_verifications v where v.business_id=bid order by v.created_at desc limit 1;
  return json_build_object('allowed',coalesce(st,'none')='approved','status',coalesce(st,'none'),'business_id',bid);
end; $$;
grant execute on function merchant_dashboard_access() to authenticated;

-- Prevent ordinary users from inserting a business for another account.
drop policy if exists businesses_owner_insert on businesses;
create policy businesses_owner_insert on businesses for insert to authenticated
with check (owner_user_id=auth.uid());

-- Owner can see only their own business details.
drop policy if exists businesses_owner_read on businesses;
create policy businesses_owner_read on businesses for select to authenticated
using (owner_user_id=auth.uid());

-- Identity submissions can only be created for a business owned by the logged-in user.
drop policy if exists verification_insert_owner on business_verifications;
create policy verification_insert_owner on business_verifications for insert to authenticated
with check (status='pending' and exists (select 1 from businesses b where b.id=business_id and b.owner_user_id=auth.uid()));

-- No authenticated SELECT policy is added for identity records; admin review should use a protected server/admin environment.


-- Douri DZ v1.5: protected admin review panel
create table if not exists admin_users (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz default now()
);
alter table admin_users enable row level security;
drop policy if exists admin_self_read on admin_users;
create policy admin_self_read on admin_users for select to authenticated using (auth.uid()=user_id);

-- Only an existing admin can change verification status.
create or replace function admin_review_verification(p_verification_id uuid, p_status text)
returns json language plpgsql security definer as $$
declare is_admin boolean;
bid uuid;
begin
  if p_status not in ('approved','rejected') then
    return json_build_object('ok',false,'error','invalid_status');
  end if;
  select exists(select 1 from admin_users where user_id=auth.uid()) into is_admin;
  if not is_admin then
    return json_build_object('ok',false,'error','not_authorized');
  end if;
  update business_verifications
    set status=p_status, reviewed_at=now()
    where id=p_verification_id
    returning business_id into bid;
  if bid is null then return json_build_object('ok',false,'error','not_found'); end if;
  if p_status='approved' then
    update businesses set is_open=true where id=bid;
  end if;
  return json_build_object('ok',true,'business_id',bid,'status',p_status);
end; $$;
revoke all on function admin_review_verification(uuid,text) from public;
grant execute on function admin_review_verification(uuid,text) to authenticated;

-- Allow only admins to read identity verification rows.
drop policy if exists verification_admin_read on business_verifications;
create policy verification_admin_read on business_verifications for select to authenticated
using (exists (select 1 from admin_users a where a.user_id=auth.uid()));

-- Allow only admins to view private identity images through short-lived signed URLs.
drop policy if exists id_verification_admin_read on storage.objects;
create policy id_verification_admin_read on storage.objects for select to authenticated
using (bucket_id='id-verification' and exists (select 1 from public.admin_users a where a.user_id=auth.uid()));

-- Douri DZ v1.6: merchant-only queue controls
create or replace function merchant_call_next(p_business_id uuid)
returns json language plpgsql security definer as $$
declare ok_owner boolean; current_id uuid; next_no int;
begin
  select exists(
    select 1 from businesses b
    where b.id=p_business_id and b.owner_user_id=auth.uid() and b.is_open=true
    and exists(select 1 from business_verifications v where v.business_id=b.id and v.status='approved')
  ) into ok_owner;
  if not ok_owner then return json_build_object('ok',false,'error','not_authorized'); end if;
  update tickets set status='done' where business_id=p_business_id and status='serving';
  select id,ticket_number into current_id,next_no from tickets where business_id=p_business_id and status='waiting' order by ticket_number limit 1;
  if current_id is null then return json_build_object('ok',false,'error','empty_queue'); end if;
  update tickets set status='serving',called_at=now() where id=current_id;
  return json_build_object('ok',true,'ticket_number',next_no);
end; $$;
revoke all on function merchant_call_next(uuid) from public;
grant execute on function merchant_call_next(uuid) to authenticated;

create or replace function set_business_open(p_business_id uuid, p_open boolean)
returns json language plpgsql security definer as $$
declare ok_owner boolean;
begin
  select exists(
    select 1 from businesses b
    where b.id=p_business_id and b.owner_user_id=auth.uid()
    and exists(select 1 from business_verifications v where v.business_id=b.id and v.status='approved')
  ) into ok_owner;
  if not ok_owner then return json_build_object('ok',false,'error','not_authorized'); end if;
  update businesses set is_open=p_open where id=p_business_id;
  return json_build_object('ok',true,'is_open',p_open);
end; $$;
revoke all on function set_business_open(uuid,boolean) from public;
grant execute on function set_business_open(uuid,boolean) to authenticated;


-- Douri DZ v1.8: ratings (public business rating, no identity data)
create table if not exists business_ratings (
  id uuid primary key default gen_random_uuid(),
  business_id uuid not null references businesses(id) on delete cascade,
  device_id text not null,
  ticket_number integer not null,
  rating integer not null check (rating between 1 and 5),
  created_at timestamptz default now(),
  unique(business_id, device_id, ticket_number)
);
create index if not exists business_ratings_business_idx on business_ratings(business_id, created_at desc);
alter table business_ratings enable row level security;
drop policy if exists ratings_public_read on business_ratings;
create policy ratings_public_read on business_ratings for select to anon, authenticated using (true);
drop policy if exists ratings_device_insert on business_ratings;
create policy ratings_device_insert on business_ratings for insert to anon, authenticated with check (rating between 1 and 5 and device_id is not null);
create or replace function submit_rating(p_business_id uuid,p_device_id text,p_ticket_number int,p_rating int)
returns json language plpgsql security definer as $$
begin
  if p_rating < 1 or p_rating > 5 then return json_build_object('ok',false,'error','invalid_rating'); end if;
  insert into business_ratings(business_id,device_id,ticket_number,rating)
  values(p_business_id,p_device_id,p_ticket_number,p_rating)
  on conflict (business_id,device_id,ticket_number) do update set rating=excluded.rating;
  return json_build_object('ok',true);
end; $$;
grant execute on function submit_rating(uuid,text,int,int) to anon, authenticated;


-- Douri DZ v1.9: public rankings and merchant daily analytics
create or replace function public_business_rankings(p_limit int default 20)
returns table(id uuid,name text,category text,city text,is_open boolean,avg_rating numeric,rating_count bigint)
language sql security definer as $$
  select b.id,b.name,b.category,b.city,b.is_open,
         coalesce(round(avg(r.rating)::numeric,1),0) as avg_rating,
         count(r.id) as rating_count
  from businesses b
  left join business_ratings r on r.business_id=b.id
  group by b.id,b.name,b.category,b.city,b.is_open
  order by coalesce(avg(r.rating),0) desc, count(r.id) desc, b.is_open desc, b.name
  limit greatest(1,least(coalesce(p_limit,20),50));
$$;
grant execute on function public_business_rankings(int) to anon, authenticated;

create or replace function merchant_daily_stats(p_business_id uuid)
returns json language plpgsql security definer as $$
declare ok_owner boolean; total_today int; served_today int; avg_wait numeric; avg_rating numeric; rating_count bigint;
begin
  select exists(select 1 from businesses b where b.id=p_business_id and b.owner_user_id=auth.uid()) into ok_owner;
  if not ok_owner then return json_build_object('error','not_authorized'); end if;
  select count(*) filter (where created_at::date=current_date), count(*) filter (where status='done' and created_at::date=current_date) into total_today,served_today from tickets where business_id=p_business_id;
  select coalesce(avg(extract(epoch from (called_at-created_at))/60.0),0) into avg_wait from tickets where business_id=p_business_id and called_at is not null and created_at::date=current_date;
  select coalesce(avg(rating),0),count(*) into avg_rating,rating_count from business_ratings where business_id=p_business_id;
  return json_build_object('tickets_today',coalesce(total_today,0),'served_today',coalesce(served_today,0),'avg_wait_minutes',round(coalesce(avg_wait,0),1),'avg_rating',round(coalesce(avg_rating,0),1),'rating_count',coalesce(rating_count,0));
end; $$;
revoke all on function merchant_daily_stats(uuid) from public;
grant execute on function merchant_daily_stats(uuid) to authenticated;


-- Douri DZ v2.0: enable realtime updates for the queue.
-- Safe to run repeatedly.
do $$
begin
  if not exists (
    select 1 from pg_publication_tables
    where pubname='supabase_realtime' and schemaname='public' and tablename='tickets'
  ) then
    alter publication supabase_realtime add table public.tickets;
  end if;
end $$;

-- Helpful grants for the client-side app. RLS remains the primary protection.
grant usage on schema public to anon, authenticated;

-- Make the ticket RPC deterministic under concurrent requests.
create or replace function take_ticket(p_business_id uuid, p_device_id text)
returns json language plpgsql security definer set search_path=public as $$
declare next_no int; ahead int;
begin
  perform pg_advisory_xact_lock(hashtext(p_business_id::text));
  if not exists (select 1 from businesses where id=p_business_id and is_open=true) then
    return json_build_object('ok',false,'error','queue_closed');
  end if;
  select coalesce(max(ticket_number),0)+1 into next_no from tickets where business_id=p_business_id;
  insert into tickets(business_id,device_id,ticket_number,status)
  values(p_business_id,p_device_id,next_no,'waiting');
  select count(*) into ahead from tickets
  where business_id=p_business_id and status='waiting' and ticket_number < next_no;
  return json_build_object('ok',true,'ticket_number',next_no,'people_ahead',ahead);
end; $$;
grant execute on function take_ticket(uuid,text) to anon, authenticated;
