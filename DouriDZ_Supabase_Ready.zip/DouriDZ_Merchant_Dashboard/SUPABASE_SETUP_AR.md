# ربط Douri DZ مع Supabase

## 1) المشروع
تم وضع رابط مشروع Supabase داخل `app/src/main/assets/index.html`:
`https://xkwyftkytdxhfguljerr.supabase.co`

## 2) مفتاح العميل
افتح Supabase ثم **Project Settings → API Keys** وانسخ **Publishable key / anon key** وضعه بدل:
`YOUR_SUPABASE_ANON_KEY`

لا تضع `service_role` أو Secret key داخل التطبيق.

## 3) قاعدة البيانات
افتح **SQL Editor**، ثم الصق كامل محتوى `supabase.sql` واضغط Run. السكربت ينشئ الجداول والسياسات ووظائف أخذ الدور، التحقق من النشاط، التخزين الخاص بصورة الهوية، والتحديث الفوري للطابور.

## 4) الهاتف
في Authentication فعّل **Phone** وSMS Provider المناسب قبل اختبار رمز SMS الحقيقي.

## 5) الهوية
Bucket `id-verification` خاص (Private). لا تجعل صور بطاقات الهوية Public. مراجعة الهوية مخصصة للمسؤولين.

## 6) المسؤول
بعد إنشاء حساب المسؤول، أضف `user_id` الخاص به إلى جدول `admin_users` من SQL Editor.

## 7) Android
المشروع يستخدم WebView لتشغيل واجهة Douri DZ، ومعه أذونات الكاميرا والموقع والإشعارات. بعد وضع مفتاح العميل وتنفيذ SQL، يمكن فتح المشروع في Android Studio وبناء APK.

## ملاحظة
هذه النسخة جاهزة للربط، لكن مفتاح Supabase العام لم أضعه لأن الصورة المرسلة تحتوي على رابط المشروع فقط. لا تستخدم أي مفتاح سري داخل APK.
